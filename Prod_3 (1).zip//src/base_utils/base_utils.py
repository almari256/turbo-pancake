from answer import answer
from datetime import datetime
import ast
import os

def get_next_question_number() : 

    if not os.path.exists('../Assets/Questions/question_counter.txt') : 

        open('../Assets/Questions/question_counter.txt' , 'w').write('1')

        number = 1

    else :

        number = int(open('../Assets/Questions/question_counter.txt').read().strip())

        open('../Assets/Questions/question_counter.txt' , 'w').write(str(number + 1))

    return number

def write_to_log(data) : 

    feedback = data.get('feedback')
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    response = open('../Assets/Logs/chat_logs.json').read().split("\n")[- 2]

    number = int(open('../Assets/Questions/question_counter.txt').read().strip())

    log_entry = f'''
Number : {number}

Feedback [{timestamp}]: {feedback}

Response : {response}
    '''

    open('../Assets/Feedback/feedback.txt' , 'a').write(f'{log_entry}\n\n')

def get_response_from_llm(data) : 

    user_message = data.get('message')

    response, images = answer.answer(user_message)

    question_number = get_next_question_number()

    bot_response = {
        'text': response,
        # 'image': images[0] if len(images) >= 1 else ''  # Can only add one image at a time, python dict cannot have duplicate keys
        # 'image' : [
        #     'https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg' , 
        #     'https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg'
        # ] # USe this if you want to send multiple images ,
        'image' : 'https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg'
        # 'image' : images
    }

    return bot_response