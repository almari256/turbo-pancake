
import json

from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from openai import OpenAI

def run_llm(prompt) :

    print('Running LLM')

    client = OpenAI()

    stream = client.chat.completions.create(
        model = 'gpt-4o' , 
        messages = [
            {
                'role' : 'user' , 
                'content' : prompt
            }
        ] , 
        stream = True
    )
    response = ''

    for chunk in stream : 

        if chunk.choices[0].delta.content : response += chunk.choices[0].delta.content

    return response


def answer(query) : 

    vc = FAISS.load_local(
        '../Assets/vectorstore/vc' , 
        embeddings = OpenAIEmbeddings(model = 'text-embedding-3-large') ,  
        allow_dangerous_deserialization = True
    ) 
    client = OpenAI()

    similar_docs = vc.similarity_search(query)

    context = ' '

    for doc in similar_docs : 

        context += f'''
        Page Content : {doc.page_content}

        source_type : {doc.metadata['source_type']}

        source_name : {doc.metadata['source_name']}

        iter_number : {doc.metadata['iter_number']}        
        '''

    images = [doc.metadata['url'] for doc in similar_docs if doc.metadata['type'] == 'image']

    prompt = open('../Assets/prompt/main_prompt.txt').read()
    prompt = prompt.format(open('../Assets/Logs/chat_logs.json').read() , context , query)

    n_response = '\n\n'.join([
        run_llm(prompt) 
        for _ 
        in range(5)
    ])

    n_prompt = open('../Assets/prompt/n_prompt.txt').read()

    response = run_llm(n_prompt.format(n_response , query))

    open('../Assets/Logs/chat_logs.json' , 'a').write(json.dumps({
        'query' : query , 
        'response' : response
    }) + '\n')

    return response , images